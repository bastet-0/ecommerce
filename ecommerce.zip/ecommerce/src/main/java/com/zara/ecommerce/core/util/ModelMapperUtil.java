package com.zara.ecommerce.core.util;

import jakarta.annotation.PostConstruct;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.ApplicationScope;

import java.util.List;
import java.util.stream.Collectors;

@ApplicationScope
@Component
public class ModelMapperUtil {
    private ModelMapper modelMapper;

    @PostConstruct
    protected void postConstruct() {
        modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
    }

    public <T> T map(Object object, Class<T> destinationType) {
        return modelMapper.map(object, destinationType);
    }

    public <T, B> List<T> mapList(List<B> list, Class<T> destinationType) {
        return list.stream().map(object -> map(object, destinationType)).collect(Collectors.toList());
    }
}
