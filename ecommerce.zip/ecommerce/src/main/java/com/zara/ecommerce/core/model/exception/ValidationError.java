package com.zara.ecommerce.core.model.exception;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class ValidationError implements Serializable {

    private String field;

    private String error;
}
