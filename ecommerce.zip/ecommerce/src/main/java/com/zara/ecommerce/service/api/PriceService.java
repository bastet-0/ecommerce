package com.zara.ecommerce.service.api;

import com.zara.ecommerce.core.exception.DataNotFoundException;
import com.zara.ecommerce.core.model.Price;

import java.time.LocalDateTime;
import java.util.List;

public interface PriceService {
    Price getPriceByDateProductIdAndBrandId(String date, Integer productId, Integer brandId) throws DataNotFoundException;
}
