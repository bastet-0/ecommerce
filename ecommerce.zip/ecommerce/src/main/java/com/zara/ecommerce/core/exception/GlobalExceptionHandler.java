package com.zara.ecommerce.core.exception;

import com.zara.ecommerce.core.model.exception.ApiError;
import com.zara.ecommerce.core.model.exception.ValidationError;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Object>
    handleConstraintViolation(ConstraintViolationException ex) {
        List<ValidationError> validationErrors = buildValidationErrors(ex.getConstraintViolations());
        HttpStatus httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
        ApiError apiError =
                new ApiError(httpStatus.value(), httpStatus.getReasonPhrase(), validationErrors);
        return new ResponseEntity<>(apiError, new HttpHeaders(), httpStatus);
    }

    private List<ValidationError>  buildValidationErrors(
            Set<ConstraintViolation<?>> violations) {
        return violations.
                stream().
                map(violation ->
                        ValidationError.builder().
                                field(
                                        Objects.requireNonNull(StreamSupport.stream(
                                                                violation.getPropertyPath().spliterator(), false).
                                                        reduce((first, second) -> second).
                                                        orElse(null)).
                                                toString()
                                ).
                                error(violation.getMessage()).
                                build()).
                collect(Collectors.toList());
    }
}
