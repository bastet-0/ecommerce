package com.zara.ecommerce.core.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.io.Serializable;

@Data
public class PriceQuery implements Serializable {

    @NotNull
    @NotEmpty
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$",
            message = "The date format must be: yyyy-MM-dd HH:mm:ss")
    private String date;

    @NotNull
    private Integer productId;

    @NotNull
    private Integer brandId;
}
