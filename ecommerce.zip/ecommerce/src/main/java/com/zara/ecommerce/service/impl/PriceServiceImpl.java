package com.zara.ecommerce.service.impl;

import com.zara.ecommerce.core.entity.PriceEntity;
import com.zara.ecommerce.core.exception.DataNotFoundException;
import com.zara.ecommerce.core.model.Price;
import com.zara.ecommerce.core.util.ModelMapperUtil;
import com.zara.ecommerce.repository.PriceRepository;
import com.zara.ecommerce.service.api.PriceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
@Transactional
public class PriceServiceImpl implements PriceService {

    @Autowired
    private PriceRepository priceRepository;

    @Autowired
    private ModelMapperUtil modelMapperUtil;

    @Override
    public Price getPriceByDateProductIdAndBrandId(String date, Integer productId, Integer brandId) throws DataNotFoundException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime dateTime = LocalDateTime.parse(date, formatter);

        PriceEntity priceEntity = priceRepository.getPriceByDateProductIdAndBrandId(dateTime, productId, brandId);

        if(null == priceEntity) {
            throw  new DataNotFoundException("Data not found");
        }
        return modelMapperUtil.map(priceEntity, Price.class);
    }
}
