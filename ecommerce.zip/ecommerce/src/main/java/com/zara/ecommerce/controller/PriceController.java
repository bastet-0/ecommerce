package com.zara.ecommerce.controller;

import com.zara.ecommerce.core.exception.DataNotFoundException;
import com.zara.ecommerce.core.model.Price;
import com.zara.ecommerce.core.model.PriceQuery;
import com.zara.ecommerce.service.api.PriceService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Validated
@RestController
@RequestMapping(value = "/prices")
public class PriceController {

    @Autowired
    private PriceService priceService;

    @GetMapping
    public ResponseEntity<Price> getPriceByDateProductIdAndBrandId(@Valid PriceQuery priceQuery, BindingResult bindingResult) throws DataNotFoundException {
        Price price = priceService.getPriceByDateProductIdAndBrandId(priceQuery.getDate(), priceQuery.getProductId(), priceQuery.getBrandId());

        return ResponseEntity.ok(price);
    }
}
