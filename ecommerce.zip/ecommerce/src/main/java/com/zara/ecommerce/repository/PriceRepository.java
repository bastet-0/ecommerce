package com.zara.ecommerce.repository;

import com.zara.ecommerce.core.entity.PriceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;

public interface PriceRepository extends JpaRepository<PriceEntity, Integer> {

    @Query("SELECT pr FROM PriceEntity pr WHERE pr.productId = :productId and pr.brandId = :brandId and :date between "
            + "pr.startDate and pr.endDate ORDER BY pr.priority DESC LIMIT 1")
    PriceEntity getPriceByDateProductIdAndBrandId(LocalDateTime date, Integer productId, Integer brandId);

}
