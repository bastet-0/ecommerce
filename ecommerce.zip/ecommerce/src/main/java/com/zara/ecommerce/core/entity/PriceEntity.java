package com.zara.ecommerce.core.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "PRICES")
@Getter
@Setter
@RequiredArgsConstructor
public class PriceEntity implements Serializable {

    @NotNull
    @Id
    private Integer priceList;

    @NotNull
    private Integer brandId;

    @NotNull
    private LocalDateTime startDate;

    @NotNull
    private LocalDateTime endDate;

    @NotNull
    private Integer productId;

    @NotNull
    private Integer priority;

    @NotNull
    private BigDecimal price;

    @NotNull
    @NotEmpty
    @Size(min = 1, max = 3)
    private String curr;
}
