package com.zara.ecommerce.constant;

public final class Constants {
    public static final Integer PRODUCT_ID = 35455;
    public static final Integer BRAND_ID = 1;

    public static final Integer YEAR = 2020;
    public static final Integer MONTH = 6;

    public static final Integer DAY_14 = 14;
    public static final Integer DAY_15 = 15;
    public static final Integer DAY_16 = 16;

    public static final Integer HOUR_10 = 10;
    public static final Integer HOUR_16 = 16;
    public static final Integer HOUR_21 = 21;

    public static final Integer MINUTES = 0;

    public static final int EXPECTED_PRICE_LIST_1 = 1;
    public static final int EXPECTED_PRICE_LIST_2 = 2;
    public static final int EXPECTED_PRICE_LIST_3 = 3;
    public static final int EXPECTED_PRICE_LIST_4 = 4;

}

