package com.zara.ecommerce;

import com.zara.ecommerce.constant.Constants;
import com.zara.ecommerce.core.entity.PriceEntity;
import com.zara.ecommerce.core.exception.DataNotFoundException;
import com.zara.ecommerce.repository.PriceRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest
public class PriceControllerTest {
    @Autowired
    private PriceRepository priceRepository;

    @Test
    public void test1_Success() throws DataNotFoundException {
        assertPrice(Constants.EXPECTED_PRICE_LIST_1, getDate(Constants.DAY_14, Constants.HOUR_10));
    }

    @Test
    public void test2_Success() throws DataNotFoundException {
        assertPrice(Constants.EXPECTED_PRICE_LIST_2, getDate(Constants.DAY_14, Constants.HOUR_16));
    }

    @Test
    public void test3_Success() throws DataNotFoundException {
        assertPrice(Constants.EXPECTED_PRICE_LIST_1, getDate(Constants.DAY_14, Constants.HOUR_21));
    }

    @Test
    public void test4_Success() throws DataNotFoundException {
        assertPrice(Constants.EXPECTED_PRICE_LIST_3, getDate(Constants.DAY_15, Constants.HOUR_10));
    }

    @Test
    public void test5_Success() throws DataNotFoundException {
        assertPrice(Constants.EXPECTED_PRICE_LIST_4, getDate(Constants.DAY_16, Constants.HOUR_21));
    }

    private void assertPrice(int expectedPriceList, LocalDateTime date) throws DataNotFoundException {
        PriceEntity price = priceRepository.getPriceByDateProductIdAndBrandId(date, Constants.PRODUCT_ID, Constants.BRAND_ID);

        assertEquals(expectedPriceList, price.getPriceList());
    }

    private LocalDateTime getDate(int day, int hour) {
        return LocalDateTime.of(Constants.YEAR, Constants.MONTH, day, hour, Constants.MINUTES);
    }
}
